/**
 * DWMarkdown Editor
 * 
 * Replaces the standard WordPress editor with a Markdown editor
 */

jQuery(document).ready(function($) {
    // Variables to store editor instances
    let markdownEditor = null;
    let languageToolResults = [];
    let charCountElement = null;
    let minCharacters = markdown_editor_vars.min_characters || 1900;
    let maxCharacters = markdown_editor_vars.max_characters || 3500;
    let maxSentenceLength = parseInt(markdown_editor_vars.editor_max_sentence_length, 10);
    if (isNaN(maxSentenceLength)) maxSentenceLength = 25;
    let autosaveTimer = null;
    let lastSavedContent = '';
    let autosaveInterval = 10000; // 10 seconds
    let hasUnsavedChanges = false;

    // Small utility: debounce
    function debounce(fn, wait) {
        let t;
        return function() {
            const ctx = this, args = arguments;
            clearTimeout(t);
            t = setTimeout(function(){ fn.apply(ctx, args); }, wait);
        };
    }

    // Sentence highlighting state
    let currentSentenceMarks = [];
    let dimMarks = [];
    let longSentenceMarks = [];

    // Ensure CodeMirror recalculates sizes after style or DOM changes
    let __dwmd_refreshing = false;
    function refreshCodeMirrorLayout() {
        try {
            const cm = window.markdownEditor && window.markdownEditor.codemirror;
            if (!cm || __dwmd_refreshing) return;
            __dwmd_refreshing = true;
            cm.refresh();
            if (window.requestAnimationFrame) {
                window.requestAnimationFrame(() => { try { cm.refresh(); } catch(e){} });
            }
            setTimeout(() => { try { cm.refresh(); } catch(e){} finally { __dwmd_refreshing = false; } }, 120);
        } catch(e) { __dwmd_refreshing = false; }
    }

    function clearCurrentAndDimMarks() {
        currentSentenceMarks.forEach(m => { try { m.clear(); } catch(e){} });
        dimMarks.forEach(m => { try { m.clear(); } catch(e){} });
        currentSentenceMarks = [];
        dimMarks = [];
    }

    function clearLongSentenceMarks() {
        longSentenceMarks.forEach(m => { try { m.clear(); } catch(e){} });
        longSentenceMarks = [];
    }

    function getSentenceRange(cm) {
        const pos = cm.getCursor();
        const doc = cm.getDoc();
        const text = doc.getValue();
        // Convert pos to absolute index
        let index = 0;
        for (let i = 0; i < pos.line; i++) {
            index += doc.getLine(i).length + 1; // +1 for \n
        }
        index += pos.ch;
        // Find sentence start
        const startIdx = (() => {
            for (let i = index - 1; i >= 0; i--) {
                const c = text[i];
                if (c === '.' || c === '!' || c === '?' || c === '\n') {
                    return i + 1;
                }
            }
            return 0;
        })();
        // Find sentence end
        const endIdx = (() => {
            for (let i = index; i < text.length; i++) {
                const c = text[i];
                if (c === '.' || c === '!' || c === '?' || c === '\n') {
                    return i + 1;
                }
            }
            return text.length;
        })();
        // Convert absolute indices back to CodeMirror positions
        function idxToPos(idx) {
            let line = 0, rem = idx;
            const last = doc.lineCount();
            while (line < last) {
                const len = doc.getLine(line).length + 1;
                if (rem < len) break;
                rem -= len;
                line++;
            }
            return { line, ch: Math.min(rem, doc.getLine(line).length) };
        }
        return { from: idxToPos(startIdx), to: idxToPos(endIdx) };
    }

    function highlightCurrentSentence(cm) {
        const highlightEnabled = markdown_editor_vars.editor_highlight_current_sentence === true || markdown_editor_vars.editor_highlight_current_sentence === '1' || parseInt(markdown_editor_vars.editor_highlight_current_sentence, 10) === 1;
        // Always clear current/dim marks but keep long-sentence marks
        clearCurrentAndDimMarks();
        // Only highlight/dim when feature enabled and editor has focus
        try { if (typeof cm.hasFocus === 'function' && !cm.hasFocus()) return; } catch(e){}
        if (!highlightEnabled) return;
        try {
            const range = getSentenceRange(cm);
            // Mark current sentence (focused)
            const sMark = cm.markText(range.from, range.to, { className: 'cm-current-sentence' });
            currentSentenceMarks.push(sMark);
            // Long sentence detection (by word count)
            const text = cm.getRange(range.from, range.to);
            const words = text.trim().split(/\s+/).filter(Boolean);
            if (maxSentenceLength && words.length > Number(maxSentenceLength)) {
                const lMark = cm.markText(range.from, range.to, { className: 'cm-long-sentence' });
                currentSentenceMarks.push(lMark);
            }
            // Dim everything before and after the current sentence
            const doc = cm.getDoc();
            const firstPos = { line: 0, ch: 0 };
            // Compute last position
            const lastLine = doc.lastLine();
            const lastPos = { line: lastLine, ch: doc.getLine(lastLine).length };
            // Before range
            if (range.from.line !== 0 || range.from.ch !== 0) {
                const beforeMark = cm.markText(firstPos, range.from, { className: 'cm-dimmed-text' });
                dimMarks.push(beforeMark);
            }
            // After range
            if (range.to.line !== lastPos.line || range.to.ch !== lastPos.ch) {
                const afterMark = cm.markText(range.to, lastPos, { className: 'cm-dimmed-text' });
                dimMarks.push(afterMark);
            }
        } catch (e) { /* no-op */ }
    }

    // Highlight all long sentences across the document
    function highlightAllLongSentences(cm) {
        clearLongSentenceMarks();
        const doc = cm.getDoc();
        const text = doc.getValue();
        if (!text) return;
        // Helper to convert absolute index to CodeMirror pos
        function idxToPos(idx) {
            let line = 0, rem = idx;
            const last = doc.lineCount();
            while (line < last) {
                const len = doc.getLine(line).length + 1; // include \n
                if (rem < len) break;
                rem -= len;
                line++;
            }
            return { line, ch: Math.min(rem, doc.getLine(line).length) };
        }
        // Scan sentences by punctuation or newline
        let start = 0;
        for (let i = 0; i <= text.length; i++) {
            const c = text[i] || '\n';
            if (c === '.' || c === '!' || c === '?' || c === '\n') {
                const end = i + 1; // include terminator
                const sentence = text.slice(start, end);
                const words = sentence.trim().split(/\s+/).filter(Boolean);
                if (words.length > Number(maxSentenceLength)) {
                    const from = idxToPos(start);
                    const to = idxToPos(end);
                    try {
                        const mark = cm.markText(from, to, { className: 'cm-long-sentence' });
                        longSentenceMarks.push(mark);
                    } catch(e){}
                }
                start = end;
            }
        }
    }
    
    // Debug panel variables
    let debugPanel = null;
    let debugLog = [];
    let isDebugging = false; // Default to disabled
    
    // Check if debugging is enabled in settings
    if (typeof markdown_editor_vars !== 'undefined' && 
        markdown_editor_vars.languagetool_debug_mode === '1') {
        isDebugging = true;
    }
    
    // Initialize debug panel for LanguageTool replacements
    function initDebugPanel() {
        if (!isDebugging) return;
        
        // Remove any existing debug panel
        $('.lt-debug-panel').remove();
        
        // Create debug panel
        debugPanel = $('<div class="lt-debug-panel"></div>');
        debugPanel.html(`
            <h3>LanguageTool Debug</h3>
            <pre id="lt-debug-content"></pre>
            <button id="lt-clear-debug">Clear</button>
            <button id="lt-close-debug">Close</button>
        `);
        
        // Add to body
        $('body').append(debugPanel);
        
        // Add event handlers for buttons
        $('#lt-clear-debug').on('click', function() {
            debugLog = [];
            updateDebugPanel();
        });

        
        
        $('#lt-close-debug').on('click', function() {
            debugPanel.remove();
            debugPanel = null;
        });
        
        // Initial update
        updateDebugPanel();
    }
    
    // Log debug message
    function logDebug(message, data) {
        if (!isDebugging) return;
        
        const timestamp = new Date().toLocaleTimeString();
        let logEntry = `[${timestamp}] ${message}`;
        
        if (data !== undefined) {
            if (typeof data === 'object') {
                try {
                    logEntry += '\n' + JSON.stringify(data, null, 2);
                } catch (e) {
                    logEntry += '\n[Object cannot be stringified]';
                }
            } else {
                logEntry += '\n' + data;
            }
        }
        
        debugLog.push(logEntry);
        
        // Keep log size reasonable
        if (debugLog.length > 50) {
            debugLog.shift();
        }
        
        updateDebugPanel();
    }
    
    // Update debug panel content
    function updateDebugPanel() {
        if (!isDebugging || !debugPanel) return;
        
        const debugContent = $('#lt-debug-content');
        debugContent.html(debugLog.join('\n\n'));
        
        // Scroll to bottom
        debugContent.scrollTop(debugContent[0].scrollHeight);
    }
    
    // Debug panel for width
    function showWidthDebug() { /* removed in production */ }

    let __dwmd_last_content_width = null;
    function adjustEditorWidth() {
        try {
            const $editor = $('.CodeMirror');
            if (!$editor.length) return;
            // Resolve editor width from localized vars first, fallback to DOM/constant
            let editorWidth = (window.markdown_editor_vars && parseInt(window.markdown_editor_vars.editor_width, 10)) || 800;
            const editorWidthInput = document.getElementById('dwmd_width_input') || document.getElementById('editor_width');
            if (editorWidthInput) {
                const w = parseInt(editorWidthInput.value, 10);
                if (!isNaN(w) && w > 0) editorWidth = w;
            }
            // Normalize
            const contentWidth = Math.max(400, Math.min(2000, editorWidth));
            if (__dwmd_last_content_width === contentWidth) {
                return; // No change; avoid refresh
            }
            __dwmd_last_content_width = contentWidth;
            // Apply CSS var used by CSS to center and constrain content width
            document.documentElement.style.setProperty('--editor-content-width', contentWidth + 'px');
            // Refresh once to apply any measurement updates
            refreshCodeMirrorLayout();
        } catch (e) { 
            // Avoid spamming console/locks in production; fail silently
        }
    }
    
    // Initialize the markdown editor
    function initMarkdownEditor() {
        console.log('DW Markdown: Starting editor initialization');
        
        // Check if SimpleMDE is available
        if (typeof SimpleMDE === 'undefined') {
            console.error('DW Markdown: SimpleMDE not loaded!');
            return;
        }
        
        // Prevent double-initialization
        try {
            if (window.markdownEditor && window.markdownEditor.codemirror) {
                console.log('DW Markdown: Editor already exists, syncing content');
                // Sync content from WP textarea if present
                const existing = window.markdownEditor;
                const cm = existing.codemirror;
                const wpContent = $('#content').val();
                if (typeof wpContent === 'string' && wpContent.length && cm) {
                    const docVal = cm.getValue();
                    if (docVal !== wpContent) {
                        cm.setValue(wpContent);
                    }
                }
                // Ensure width is correct
                adjustEditorWidth();
                try { cm && cm.refresh(); } catch(e){}
                return; // already initialized
            }
        } catch(e) { /* no-op */ }
        // Get the content from the WordPress editor
        let content = '';
        
        // Get content from the textarea (most reliable source)
        content = $('#content').val();
        
        // Create a new textarea for SimpleMDE
        if ($('#markdown-editor').length === 0) {
            $('#wp-content-wrap').after('<textarea id="markdown-editor"></textarea>');
        }
        
        // Set the initial content in the textarea
        $('#markdown-editor').val(content);
        
        // Store the initial content for comparison in autosave
        lastSavedContent = content;
        
        // Hide the WordPress editor completely
        $('#wp-content-wrap').hide();
        $('#post-status-info').hide();
        
        // Define custom button for LanguageTool
        const languageToolButton = {
            name: "languagetool",
            action: checkWithLanguageTool,
            className: "fa fa-check",
            title: "Check with LanguageTool"
        };
        
        // Initialize SimpleMDE
        markdownEditor = new SimpleMDE({
            element: document.getElementById('markdown-editor'),
            autofocus: true,
            spellChecker: false,
            lineWrapping: true,
            toolbar: [
                'bold', 'italic', 'heading', '|',
                'quote', 'unordered-list', 'ordered-list', '|',
                'link', 'image', '|',
                'fullscreen', '|',
                languageToolButton, '|',
                'guide'
            ],
            renderingConfig: {
                singleLineBreaks: true,
                codeSyntaxHighlighting: true,
            },
            status: ['lines', 'words', 'cursor'],
            placeholder: 'Write your content in Markdown...',
            shortcuts: {
                'togglePreview': null,
                'toggleSideBySide': null,
                'toggleFullScreen': 'F11',
                'drawLink': null  // Explicitly disable the built-in link shortcut
            }
        });
        
        // Make the editor instance globally accessible
        window.markdownEditor = markdownEditor;
        
        // Expose CodeMirror instance if needed by other DWMarkdown scripts
        // window.dwMarkdownEditorCM = markdownEditor.codemirror;
        
        // Get the CodeMirror instance
        const cm = markdownEditor.codemirror;

        // Ensure preview modes are not active and no preview panes exist
        try {
            const wrapper = cm.getWrapperElement();
            $(wrapper).removeClass('sided-preview');
            $(wrapper).removeClass('preview-active');
            $('.editor-preview, .editor-preview-side').remove();
        } catch (e) { /* no-op */ }

        // Apply editor width - multiple attempts to ensure it takes
        adjustEditorWidth();
        refreshCodeMirrorLayout();
        
        // Force additional layout calculations after SimpleMDE is fully ready
        setTimeout(() => {
            adjustEditorWidth();
            refreshCodeMirrorLayout();
        }, 100);
        
        setTimeout(() => {
            adjustEditorWidth();
            refreshCodeMirrorLayout();
        }, 300);
        
        // On resize
        $(window).off('dwmd.adjustWidth').on('dwmd.adjustWidth', adjustEditorWidth);
        // Debounced resize with CodeMirror refresh
        const debouncedResize = debounce(function(){
            adjustEditorWidth();
            refreshCodeMirrorLayout();
        }, 150);
        $(window).off('resize.dwmd').on('resize.dwmd', debouncedResize);
        
        // Apply scoped CSS class to encapsulate editor styles
        try {
            if (cm && cm.getWrapperElement) {
                const wrapper = cm.getWrapperElement();
                wrapper.classList.add('dwmd-editor');
                console.log('DW Markdown: Applied dwmd-editor class to', wrapper);
                
                // Encourage wrapping to avoid horizontal scrollbars
                cm.setOption('lineWrapping', true);
                // Render full document without virtual viewport to avoid inner scrollbars
                if (typeof cm.setOption === 'function') {
                    cm.setOption('viewportMargin', Infinity);
                }
                // Let CodeMirror auto-size height; we'll manage width via CSS var
                if (typeof cm.setSize === 'function') {
                    cm.setSize(null, 'auto');
                }
                // Ensure wrapper and scroll area don't constrain height
                try {
                    const scroller = wrapper.querySelector('.CodeMirror-scroll');
                    if (scroller) {
                        scroller.style.height = 'auto';
                        scroller.style.maxHeight = 'none';
                        scroller.style.overflowY = 'visible';
                    }
                    wrapper.style.height = 'auto';
                    wrapper.style.maxHeight = 'none';
                } catch(e) { /* no-op */ }
                
                // Force a refresh to apply styles
                setTimeout(() => {
                    try { 
                        cm.refresh(); 
                        console.log('DW Markdown: Editor refreshed');
                    } catch(e) { console.error('DW Markdown: Refresh error', e); }
                }, 100);
            } else {
                console.error('DW Markdown: CodeMirror instance or wrapper not found', cm);
            }
        } catch(e) { 
            console.error('DW Markdown: Error applying editor class', e);
        }

        // On CodeMirror events, avoid triggering width/refresh loops
        if (cm) {
            const debouncedLongs = debounce(function(inst){ highlightAllLongSentences(inst); }, 200);
            cm.on('refresh', function(){
                // Only semantic updates, no width/refresh calls here
                try { highlightCurrentSentence(cm); debouncedLongs(cm); } catch(e){}
            });
            cm.on('cursorActivity', function(inst){ try { highlightCurrentSentence(inst); } catch(e){} });
            cm.on('change', function(inst){ try { highlightCurrentSentence(inst); debouncedLongs(inst); } catch(e){} });
            setTimeout(function(){ try { highlightCurrentSentence(cm); debouncedLongs(cm); } catch(e){} }, 0);
            // When editor gains focus, re-apply current sentence highlighting
            cm.on('focus', function(inst){
                try { highlightCurrentSentence(inst); } catch(e){}
            });
            // When editor loses focus, clear dimming so everything is undimmed
            cm.on('blur', function(){
                try { clearCurrentAndDimMarks(); } catch(e){}
            });

            // HTML -> Markdown on paste using Turndown
            function isInFencedCode(cmInst, pos) {
                try {
                    const doc = cmInst.getDoc();
                    const cursor = pos || doc.getCursor();
                    let openFences = 0;
                    for (let l = 0; l <= cursor.line; l++) {
                        const line = doc.getLine(l);
                        if (/^```/.test(line.trim())) {
                            openFences++;
                        }
                    }
                    return (openFences % 2) === 1; // inside if odd
                } catch (e) { return false; }
            }

            cm.on('paste', function(inst, e){
                try {
                    const dt = e && (e.clipboardData || window.clipboardData);
                    if (!dt) return;
                    // If files (e.g., images) present, let default handling occur
                    if (dt.files && dt.files.length) return;

                    const html = dt.getData && dt.getData('text/html');
                    if (!html) return; // allow normal paste for plain text

                    // Avoid converting inside fenced code blocks
                    if (isInFencedCode(inst)) return;

                    // Ensure Turndown is available
                    if (typeof window.TurndownService === 'undefined') return;

                    e.preventDefault();

                    const td = new window.TurndownService({
                        headingStyle: 'atx',
                        codeBlockStyle: 'fenced',
                        emDelimiter: '*',
                        bulletListMarker: '-',
                        hr: '---',
                        br: '\n'
                    });
                    if (window.turndownPluginGfm && typeof window.turndownPluginGfm.gfm === 'function') {
                        td.use(window.turndownPluginGfm.gfm);
                    }
                    // Strip style/script and Word cruft aggressively
                    td.remove(['style', 'script']);

                    let md = '';
                    try { md = td.turndown(html); } catch(err) { md = dt.getData('text/plain') || ''; }
                    if (!md) return;

                    inst.replaceSelection(md, 'around');
                } catch (err) {
                    // Fail quietly to avoid blocking normal paste
                }
            });
        }
        
        // Improve touch device support, especially for iPad
        
        // Detect if we're on iOS (iPad/iPhone)
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || 
                     (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
        
        if (isIOS) {
            console.log('iOS device detected, enhancing touch support');
            
            // Add custom class to the editor for iOS-specific styling
            $(cm.getWrapperElement()).addClass('ios-device');
            
            // Add iOS-specific CSS
            const iosStyles = document.createElement('style');
            iosStyles.textContent = `
                /* iOS-specific editor styles */
                .CodeMirror.ios-device {
                    -webkit-tap-highlight-color: rgba(0,0,0,0.1);
                    touch-action: manipulation;
                }
                
                /* Make selection more visible on iOS */
                .CodeMirror.ios-device .CodeMirror-selected {
                    background-color: rgba(0, 120, 215, 0.4) !important;
                }
                
                /* iOS formatting toolbar */
                .ios-formatting-toolbar {
                    display: flex;
                    padding: 8px;
                    background: #f5f5f5;
                    border-bottom: 1px solid #ddd;
                    margin-bottom: 8px;
                }
                
                .ios-formatting-toolbar button {
                    flex: 1;
                    margin: 0 4px;
                    padding: 8px 12px;
                    background: #fff;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    font-size: 14px;
                    font-weight: 500;
                    color: #333;
                    touch-action: manipulation;
                }
                
                .ios-bold-btn {
                    font-weight: bold !important;
                }
                
                .ios-italic-btn {
                    font-style: italic !important;
                }
            `;
            document.head.appendChild(iosStyles);
            
            // Improve double-tap selection on iOS
            $(cm.getWrapperElement()).on('touchend', function(e) {
                // Check if this is a double-tap
                const now = new Date().getTime();
                const lastTap = $(this).data('lastTap') || 0;
                const timeDiff = now - lastTap;
                
                if (timeDiff < 300 && timeDiff > 0) {
                    // This is a double-tap, try to select the word at the tap position
                    e.preventDefault();
                    
                    // Get the position in the editor where the user tapped
                    const pos = cm.coordsChar({
                        left: e.originalEvent.changedTouches[0].pageX,
                        top: e.originalEvent.changedTouches[0].pageY
                    });
                    
                    // Find word boundaries
                    const wordRange = cm.findWordAt(pos);
                    
                    // Select the word
                    cm.setSelection(wordRange.anchor, wordRange.head);
                }
                
                $(this).data('lastTap', now);
            });
            
            // Handle system-level formatting on iOS
            // This uses MutationObserver to detect when the system applies formatting
            const editorElement = cm.getWrapperElement().querySelector('.CodeMirror-sizer');
            
            // Create a mutation observer to watch for style changes
            const observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    // Check if this is a style-related mutation
                    if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                        const selection = cm.getSelection();
                        if (selection && selection.length > 0) {
                            // Check if text has been styled
                            const hasItalic = document.queryCommandState('italic');
                            const hasBold = document.queryCommandState('bold');
                            
                            // Apply markdown formatting
                            if (hasItalic && hasBold) {
                                // Both bold and italic
                                cm.replaceSelection(`***${selection}***`);
                            } else if (hasBold) {
                                // Just bold
                                cm.replaceSelection(`**${selection}**`);
                            } else if (hasItalic) {
                                // Just italic
                                cm.replaceSelection(`*${selection}*`);
                            }
                            
                            // Clear any system-applied formatting
                            document.execCommand('removeFormat');
                        }
                    }
                });
            });
            
            // Start observing the editor for style changes
            observer.observe(editorElement, { 
                attributes: true,
                subtree: true,
                attributeFilter: ['style']
            });
            
            // Add custom toolbar buttons specifically for iOS
            const toolbar = markdownEditor.toolbar;
            
            // Add more prominent formatting buttons for iOS
            if (toolbar && toolbar.length) {
                const iosToolbarDiv = document.createElement('div');
                iosToolbarDiv.className = 'ios-formatting-toolbar';
                iosToolbarDiv.innerHTML = `
                    <button type="button" class="ios-bold-btn">Bold</button>
                    <button type="button" class="ios-italic-btn">Italic</button>
                    <button type="button" class="ios-heading-btn">Heading</button>
                `;
                
                // Insert the iOS toolbar before the editor
                $(cm.getWrapperElement()).before(iosToolbarDiv);
                
                // Add event handlers
                $('.ios-bold-btn').on('click', function() {
                    const selection = cm.getSelection();
                    if (selection && selection.length > 0) {
                        cm.replaceSelection(`**${selection}**`);
                    } else {
                        cm.replaceSelection('****');
                        const cursor = cm.getCursor();
                        cm.setCursor({line: cursor.line, ch: cursor.ch - 2});
                    }
                    cm.focus();
                });
                
                $('.ios-italic-btn').on('click', function() {
                    const selection = cm.getSelection();
                    if (selection && selection.length > 0) {
                        cm.replaceSelection(`*${selection}*`);
                    } else {
                        cm.replaceSelection('**');
                        const cursor = cm.getCursor();
                        cm.setCursor({line: cursor.line, ch: cursor.ch - 1});
                    }
                    cm.focus();
                });
                
                $('.ios-heading-btn').on('click', function() {
                    const cursor = cm.getCursor();
                    cm.replaceRange('# ', {line: cursor.line, ch: 0});
                    cm.focus();
                });
            }
        }
        
        // Character count display in admin bar
        function updateCharCount() {
            const text = cm.getValue();
            const length = text.replace(/\s+/g, ' ').trim().length;
            const hasSelection = cm.somethingSelected();
            const selectionLength = hasSelection ? cm.getSelection().replace(/\s+/g, ' ').trim().length : 0;
            
            if (!charCountElement) {
                const $elem = $('<div id="wp-admin-bar-char-count" class="ab-top-secondary"></div>');
                const $item = $('<div class="ab-item">0</div>');
                $elem.append($item);
                $('#wp-admin-bar-top-secondary').append($elem);
                charCountElement = $item;
            }
            
            if (charCountElement) {
                let text = `${length} chars`;
                charCountElement.removeClass('char-count-warning char-count-success char-count-selection');
                if (hasSelection && selectionLength > 0) {
                    text += ` • ${selectionLength} selected`;
                    charCountElement.addClass('char-count-selection');
                } else if (length < minCharacters) {
                    charCountElement.addClass('char-count-warning');
                } else if (length > maxCharacters) {
                    charCountElement.addClass('char-count-warning');
                } else {
                    charCountElement.addClass('char-count-success');
                }
                charCountElement.text(text);
            }
        }
        
        // Update char count on changes
        cm.on('change', function() {
            hasUnsavedChanges = true;
            updateCharCount();
        });
        
        cm.on('cursorActivity', function() {
            updateCharCount();
        });
        
        // Initialize character count after editor setup
        setTimeout(updateCharCount, 500);
        
        // Final aggressive layout fix after everything is settled
        setTimeout(() => {
            adjustEditorWidth();
            refreshCodeMirrorLayout();
            // Force a DOM reflow
            if (cm && cm.getWrapperElement()) {
                const wrapper = cm.getWrapperElement();
                wrapper.style.display = 'none';
                wrapper.offsetHeight; // Force reflow
                wrapper.style.display = '';
                cm.refresh();
            }
        }, 600);
        
        // Autosave integration
        function performAutosave() {
            const currentContent = cm.getValue();
            if (currentContent === lastSavedContent) {
                return;
            }
            lastSavedContent = currentContent;
            hasUnsavedChanges = false;
            try {
                if (typeof wp !== 'undefined' && wp.autosave && typeof wp.autosave.server === 'function') {
                    wp.autosave.server();
                } else {
                    // Fallback AJAX post update
                    const postID = markdown_editor_vars.post_id;
                    if (!postID) return;
                    const formData = new FormData();
                    formData.append('action', 'dwmarkdown_autosave');
                    formData.append('post_ID', postID);
                    formData.append('content', currentContent);
                    if (markdown_editor_vars.autosave_nonce) {
                        formData.append('_dwmarkdown_nonce', markdown_editor_vars.autosave_nonce);
                    }
                    fetch(markdown_editor_vars.ajax_url, { method: 'POST', credentials: 'same-origin', body: formData });
                }
            } catch (e) {
                /* no-op */
            }
        }
        
        function scheduleAutosave() {
            if (autosaveTimer) clearTimeout(autosaveTimer);
            autosaveTimer = setTimeout(performAutosave, autosaveInterval);
        }
        
        cm.on('change', scheduleAutosave);
        
        // LanguageTool integration
        function clearLanguageToolResults() {
            languageToolResults = [];
            const marks = cm.getAllMarks();
            marks.forEach(m => {
                if (m.className === 'languagetool-error' || m.className === 'languagetool-error-message') {
                    m.clear();
                }
            });
            $('.languagetool-tooltip').remove();
        }
        
        function checkWithLanguageTool() {
            const text = cm.getValue();
            if (!text || !text.trim()) {
                return;
            }
            clearLanguageToolResults();
            
            // Using public LanguageTool API (rate-limited). Consider self-hosting for production.
            const url = 'https://api.languagetool.org/v2/check';
            const params = new URLSearchParams();
            params.append('text', text);
            params.append('language', 'en-US');
            
            logDebug('Sending LanguageTool request', { length: text.length });
            
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: params.toString()
            })
            .then(resp => resp.json())
            .then(data => {
                logDebug('LanguageTool response', data);
                if (!data || !data.matches) return;
                languageToolResults = data.matches;
                
                // Highlight errors
                data.matches.forEach(match => {
                    try {
                        const from = cm.posFromIndex(match.offset);
                        const to = cm.posFromIndex(match.offset + match.length);
                        const marker = cm.markText(from, to, {
                            className: 'languagetool-error'
                        });
                        marker.__dw = { match };
                    } catch (e) {
                        // ignore marking errors
                    }
                });
                
                initDebugPanel();
            })
            .catch(err => {
                logDebug('LanguageTool error', String(err));
            });
        }
        
        // Tooltip handling for LanguageTool markers
        $(cm.getWrapperElement()).on('mouseover.languagetool', '.languagetool-error', function(e) {
            const target = e.target;
            const marks = cm.findMarksAt(cm.coordsChar({left: e.pageX, top: e.pageY}));
            let match = null;
            marks.forEach(m => { if (m.className === 'languagetool-error' && m.__dw) match = m.__dw.match; });
            if (!match) return;
            
            const tooltip = $('<div class="languagetool-tooltip"></div>');
            const msg = match.message || 'Issue';
            const repl = (match.replacements || []).slice(0, 5);
            const rule = match.rule && (match.rule.description || match.rule.id) ? (match.rule.description || match.rule.id) : '';
            
            let html = '';
            html += `<h4>${msg}</h4>`;
            if (rule) html += `<p>${rule}</p>`;
            if (repl.length) {
                html += '<div class="replacements">';
                repl.forEach(r => {
                    const val = r.value || '';
                    html += `<span class="replacement">${val}</span>`;
                });
                html += '</div>';
            }
            tooltip.html(html);
            $('body').append(tooltip);
            
            const move = (ev) => {
                tooltip.css({ left: ev.pageX + 12, top: ev.pageY + 12 });
            };
            move(e);
            $(document).on('mousemove.lt', move);
            
            const cleanup = () => {
                $(document).off('mousemove.lt', move);
                tooltip.remove();
            };
            $(this).one('mouseout', cleanup);
        });
        
        // Click on replacement to apply
        $(document).on('click', '.languagetool-tooltip .replacement', function() {
            const text = $(this).text();
            const el = document.elementFromPoint(parseInt($(this).closest('.languagetool-tooltip').css('left')) - 12, parseInt($(this).closest('.languagetool-tooltip').css('top')) - 12);
            // Find active selection and replace
            const sels = cm.listSelections();
            if (sels && sels.length) {
                cm.replaceSelection(text, 'around');
            }
        });

        // Ensure Markdown content is saved in the native WP content field
        // Sync on post form submit and manual saves
        const syncToWpContent = () => {
            try {
                const value = cm.getValue();
                $('#content').val(value);
            } catch (e) {}
        };
        // Classic editor form submit
        $('#post').on('submit.dwmarkdown', function() {
            syncToWpContent();
        });
        // Update the hidden field whenever autosave triggers
        cm.on('change', function() {
            syncToWpContent();
        });
    }
    
    // Initialize when DOM is ready and WP editor is present
    console.log('DW Markdown: DOM ready, checking conditions...');
    console.log('DW Markdown: Content element exists:', $('#content').length > 0);
    console.log('DW Markdown: Page now:', window.pagenow);
    console.log('DW Markdown: SimpleMDE available:', typeof SimpleMDE !== 'undefined');
    
    // Always initialize on any post type if we have the content field
    // No longer checking pagenow === 'post' || pagenow === 'page'
    if ($('#content').length && typeof SimpleMDE !== 'undefined') {
        console.log('DW Markdown: All conditions met, initializing...');
        initMarkdownEditor();
    } else {
        console.log('DW Markdown: Conditions not met for initialization');
        // Try again after a short delay in case content field isn't ready yet
        setTimeout(() => {
            if ($('#content').length && typeof SimpleMDE !== 'undefined') {
                console.log('DW Markdown: Delayed initialization');
                initMarkdownEditor();
            } else {
                console.log('DW Markdown: Still cannot initialize after delay');
            }
        }, 500);
    }
});
