<?php
/**
 * Markdown utilities extracted for DW Markdown plugin
 *
 * @package DWMarkdown
 */

if (!defined('ABSPATH')) {
    exit;
}

class Content_Generator_Markdown_Utils {
    public static function html_to_markdown($html) {
        $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');
        if ((strpos($html, '<') === false || substr_count($html, '<') < 3) &&
            (preg_match('/^#+\s+.+$/m', $html) ||
             preg_match('/^[\*\-\+]\s+.+$/m', $html) ||
             preg_match('/\[.+\]\(.+\)/', $html) ||
             preg_match('/\*\*.+\*\*/', $html) ||
             preg_match('/\*.+\*/', $html))) {
            return $html;
        }

        // Basic conversions
        $markdown = $html;
        $markdown = preg_replace('/<h2[^>]*>(.*?)<\/h2>/is', "\n## $1\n", $markdown);
        $markdown = preg_replace('/<h1[^>]*>(.*?)<\/h1>/is', "\n# $1\n", $markdown);
        $markdown = preg_replace('/<h3[^>]*>(.*?)<\/h3>/is', "\n### $1\n", $markdown);
        $markdown = preg_replace('/<h4[^>]*>(.*?)<\/h4>/is', "\n#### $1\n", $markdown);
        $markdown = preg_replace('/<h5[^>]*>(.*?)<\/h5>/is', "\n##### $1\n", $markdown);
        $markdown = preg_replace('/<h6[^>]*>(.*?)<\/h6>/is', "\n###### $1\n", $markdown);
        $markdown = preg_replace('/<p[^>]*>(.*?)<\/p>/is', '$1' . PHP_EOL . PHP_EOL, $markdown);
        $markdown = preg_replace('/<(strong|b)[^>]*>(.*?)<\/(strong|b)>/is', '**$2**', $markdown);
        $markdown = preg_replace('/<(em|i)[^>]*>(.*?)<\/(em|i)>/is', '*$2*', $markdown);
        $markdown = preg_replace('/<a[^>]*href=["\'](.*?)["\'][^>]*>(.*?)<\/a>/is', '[$2]($1)', $markdown);
        $markdown = preg_replace('/<ul[^>]*>(.*?)<\/ul>/is', '$1', $markdown);
        $markdown = preg_replace('/<ol[^>]*>(.*?)<\/ol>/is', '$1', $markdown);
        $markdown = preg_replace('/<li[^>]*>(.*?)<\/li>/is', '- $1' . PHP_EOL, $markdown);
        $markdown = preg_replace('/<blockquote[^>]*>(.*?)<\/blockquote>/is', '> $1', $markdown);
        $markdown = preg_replace('/<pre[^>]*><code[^>]*>(.*?)<\/code><\/pre>/is', '```' . PHP_EOL . '$1' . PHP_EOL . '```', $markdown);
        $markdown = preg_replace('/<code[^>]*>(.*?)<\/code>/is', '`$1`', $markdown);
        $markdown = preg_replace('/<hr[^>]*>/is', '---', $markdown);
        $markdown = strip_tags($markdown);
        $markdown = preg_replace('/\n{3,}/', "\n\n", $markdown);
        $markdown = preg_replace('/([^\n])\n(#[#]{0,5} )/m', "$1\n\n$2", $markdown);
        $markdown = preg_replace('/^([#]{1,6} .*)\n([^#\n])/m', "$1\n\n$2", $markdown);
        return $markdown;
    }

    public static function preprocess_markdown($markdown) {
        $markdown = preg_replace('/\[note:(.*?)\]/', '> **Note:** $1', $markdown);
        $markdown = preg_replace('/\[warning:(.*?)\]/', '> **Warning:** $1', $markdown);
        $markdown = preg_replace('/\[info:(.*?)\]/', '> **Info:** $1', $markdown);
        return $markdown;
    }

    public static function markdown_to_html($markdown) {
        $markdown = self::preprocess_markdown($markdown);

        // Temporarily disable Parsedown path to ensure reliable output using the fallback parser
        if (false && class_exists('Parsedown')) {
            $parts = preg_split('/(```.*?```|`.*?`)/s', $markdown, -1, PREG_SPLIT_DELIM_CAPTURE);
            $markdown = '';
            foreach ($parts as $i => $part) {
                if ($i % 2 === 0) {
                    $lines = explode("\n", $part);
                    $result = '';
                    for ($j = 0; $j < count($lines); $j++) {
                        $current = $lines[$j];
                        $result .= $current;
                        if ($j < count($lines) - 1) {
                            $next = $lines[$j + 1];
                            if (trim($current) !== '' && trim($next) !== '') {
                                $result .= '<br/>';
                            }
                            $result .= "\n";
                        }
                    }
                    $part = $result;
                }
                $markdown .= $part;
            }
            $pd = new Parsedown();
            // Defaults: compact line breaks ON
            if (method_exists($pd, 'setSafeMode')) { $pd->setSafeMode(false); }
            if (method_exists($pd, 'setBreaksEnabled')) { $pd->setBreaksEnabled(true); }
            $html = $pd->text($markdown);
            $html = self::format_html_for_wordpress($html);
            $html = self::ensure_paragraphs($html);
            // Temporarily avoid KSES sanitization to verify output isn't stripped
            return $html;
        }

        // Fallback basic parsing
        $html = $markdown;
        $html = preg_replace('/^(\s+)[\*\-]\s+/m', '- ', $html);
        $html = preg_replace('/^(\s+)(\d+)\.\s+/m', '$2. ', $html);
        $html = preg_replace('/^#\s+(.*?)$/m', '<h1>$1</h1>', $html);
        $html = preg_replace('/^##\s+(.*?)$/m', '<h2>$1</h2>', $html);
        $html = preg_replace('/^###\s+(.*?)$/m', '<h3>$1</h3>', $html);
        $html = preg_replace('/^####\s+(.*?)$/m', '<h4>$1</h4>', $html);
        $html = preg_replace('/^#####\s+(.*?)$/m', '<h5>$1</h5>', $html);
        $html = preg_replace('/^######\s+(.*?)$/m', '<h6>$1</h6>', $html);
        // Unescape common Google Docs export quirk: "\!" should render as '!'
        $html = str_replace('\\!', '!', $html);
        // Protect escaped brackets so they don't interact with link parsing
        $html = str_replace(['\\[', '\\]'], ['&#91;', '&#93;'], $html);
        // Stricter link regex: stop at the first ']' and ')', avoid spanning the rest of the paragraph
        $html = preg_replace('/\[([^\]]+)\]\(([^)\s]+)\)/', '<a href="$2">$1</a>', $html);
        $html = preg_replace('/\*\*(.*?)\*\*/s', '<strong>$1</strong>', $html);
        $html = preg_replace('/\*(.*?)\*/s', '<em>$1</em>', $html);
        // Underscore emphasis with word-safe boundaries
        $html = preg_replace('/(?<!\w)__(?!\s)(.+?)(?<!\s)__(?!\w)/s', '<strong>$1</strong>', $html);
        $html = preg_replace('/(?<!\w)_(?!\s)(.+?)(?<!\s)_(?!\w)/s', '<em>$1</em>', $html);
        // Lists: use placeholders to avoid nesting <ol> inside <ul> or vice versa
        // Convert unordered list markers to placeholders
        $html = preg_replace('/^\s*[\*\-]\s+(.*)$/m', '__ULI__$1', $html);
        // Convert ordered list markers to placeholders
        $html = preg_replace('/^\s*\d+\.\s+(.*)$/m', '__OLI__$1', $html);

        // Wrap ordered list blocks first
        $html = preg_replace_callback('/(?:^|\n)((?:__OLI__.*\n?)+)/', function($m){
            $block = trim($m[1]);
            if ($block === '') return $m[0];
            $lines = preg_split('/\n/', $block);
            $lis = '';
            foreach ($lines as $line) {
                if ($line === '') continue;
                $text = preg_replace('/^__OLI__/', '', $line);
                $lis .= '<li>' . $text . '</li>';
            }
            return "\n<ol>" . $lis . '</ol>';
        }, $html);

        // Then wrap unordered list blocks
        $html = preg_replace_callback('/(?:^|\n)((?:__ULI__.*\n?)+)/', function($m){
            $block = trim($m[1]);
            if ($block === '') return $m[0];
            $lines = preg_split('/\n/', $block);
            $lis = '';
            foreach ($lines as $line) {
                if ($line === '') continue;
                $text = preg_replace('/^__ULI__/', '', $line);
                $lis .= '<li>' . $text . '</li>';
            }
            return "\n<ul>" . $lis . '</ul>';
        }, $html);
        $html = preg_replace('/```(.*?)```/s', '<pre><code>$1</code></pre>', $html);
        $html = preg_replace('/`(.*?)`/s', '<code>$1</code>', $html);
        $html = preg_replace('/^>\s+(.*?)$/m', '<blockquote>$1</blockquote>', $html);
        $lines = explode("\n", $html);
        $result = '';
        for ($i = 0; $i < count($lines); $i++) {
            $current = $lines[$i];
            $result .= $current;
            if ($i < count($lines) - 1) {
                $next = $lines[$i + 1];
                // Don't add <br/> if we're inside a list context or between elements that should be separated
                $in_list_context = preg_match('/<li>|<\/li>|<ul>|<\/ul>|<ol>|<\/ol>/', $current) || 
                                  preg_match('/<li>|<\/li>|<ul>|<\/ul>|<ol>|<\/ol>/', $next);
                $has_block_element = preg_match('/<\/?(h\d|p|blockquote|pre|div|table)[^>]*>/', $current) || 
                                    preg_match('/<\/?(h\d|p|blockquote|pre|div|table)[^>]*>/', $next);
                
                if (trim($current) !== '' && trim($next) !== '' && 
                    !preg_match('/<[^>]*$/', $current) && 
                    !preg_match('/^[^<]*>/', $next) &&
                    !$in_list_context &&
                    !$has_block_element) {
                    $result .= '<br/>';
                }
                $result .= "\n";
            }
        }
        $html = $result;
        $html = preg_replace('/^(?!<h|<ul|<li|<blockquote|<pre)(.*?)$/m', '<p>$1</p>', $html);
        $html = self::format_html_for_wordpress($html);
        return $html;
    }

    public static function safe_html_to_markdown($html) {
        if (empty($html)) return '';
        try {
            if ((strpos($html, '<') === false || substr_count($html, '<') < 3) &&
                (preg_match('/^#+\s+.+$/m', $html) || preg_match('/^[\*\-\+]\s+.+$/m', $html) || preg_match('/\[.+\]\(.+\)/', $html) || preg_match('/\*\*.+\*\*/', $html) || preg_match('/\*.+\*/', $html))) {
                return $html;
            }
            $markdown = self::html_to_markdown($html);
            if (empty($markdown)) {
                $markdown = strip_tags($html);
                $markdown = str_replace(['<br>', '<br/>', '<br />'], "\n", $markdown);
                $markdown = preg_replace('/\n{3,}/', "\n\n", $markdown);
            }
            return $markdown;
        } catch (Exception $e) {
            return strip_tags($html);
        }
    }

    private static function format_html_for_wordpress($html) {
        $html = preg_replace('/<\/p>\s*<p>/', "</p>\n\n<p>", $html);
        $html = preg_replace('/<\/ul>\s*<ul>/', "</ul>\n\n<ul>", $html);
        $html = preg_replace('/<\/ol>\s*<ol>/', "</ol>\n\n<ol>", $html);
        $html = preg_replace('/<\/blockquote>\s*<blockquote>/', "</blockquote>\n\n<blockquote>", $html);
        return $html;
    }

    private static function ensure_paragraphs($html) {
        if (empty($html)) return $html;
        if (strpos($html, '<p>') !== false) return $html;
        $parts = preg_split('/\n\s*\n/', $html, -1, PREG_SPLIT_NO_EMPTY);
        if (!$parts) return $html;
        $out = '';
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p === '') continue;
            // Skip wrapping if already a block element
            if (preg_match('/^(<h\d|<ul|<ol|<li|<blockquote|<pre|<div|<section|<article|<table)/i', $p)) {
                $out .= $p . "\n\n";
            } else {
                $out .= '<p>' . $p . '</p>' . "\n\n";
            }
        }
        return trim($out);
    }
}
