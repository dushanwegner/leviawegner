<?php
/**
 * Plugin Name: DW Markdown
 * Description: Standalone Markdown editor. Replaces the classic editor with SimpleMDE and renders Markdown on the front end.
 * Version: 1.25.09.04.01
 * Author: Dushan Wegner
 * Author URI: https://dushanwegner.com
 * License: GPL2
 * Text Domain: dwmarkdown
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('DWMARKDOWN_VERSION')) {
    define('DWMARKDOWN_VERSION', '1.25.09.04.01');
}

class DWMarkdown {
    public function __construct() {
        // Admin/editor integration
        add_action('admin_enqueue_scripts', array($this, 'enqueue_markdown_editor_assets'));
        add_filter('replace_editor', array($this, 'replace_editor'), 10, 2);
        add_action('save_post', array($this, 'mark_post_as_markdown'), 10, 2);
        add_action('wp_ajax_dwmarkdown_autosave', array($this, 'handle_autosave'));

        // Per-post disable meta box
        add_action('add_meta_boxes', array($this, 'add_disable_metabox'));
        add_action('save_post', array($this, 'save_disable_metabox'), 5, 2);

        // Per-post cards meta box
        add_action('add_meta_boxes', array($this, 'add_cards_metabox'));
        add_action('save_post', array($this, 'save_cards_metabox'), 5, 2);

        // When DW Markdown is disabled for a post, force classic editor to light colors to avoid white text from core dark editor CSS
        add_action('admin_head-post.php', array($this, 'output_classic_editor_lightmode_css'));
        add_action('admin_head-post-new.php', array($this, 'output_classic_editor_lightmode_css'));
        add_filter('tiny_mce_before_init', array($this, 'tweak_classic_editor_tinymce_styles'), 10, 1);
        add_filter('admin_body_class', array($this, 'maybe_add_disabled_body_class'));
        add_filter('mce_css', array($this, 'maybe_strip_theme_mce_css'));

        // Disable Gutenberg (block editor) for all post types so DWMarkdown can take over
        add_filter('use_block_editor_for_post', '__return_false', 10);
        add_filter('use_block_editor_for_post_type', '__return_false', 10);
        // For older/newer Gutenberg checks
        add_filter('gutenberg_can_edit_post_type', '__return_false', 10);

        // Deactivation modal on Plugins screen (like EssayToolkit)
        add_action('admin_footer-plugins.php', array($this, 'plugins_deactivation_modal'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_plugins_screen_assets'));

        // Settings
        add_action('admin_menu', array($this, 'register_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));

        // Front-end rendering
        add_filter('the_content', array($this, 'maybe_disable_wpautop'), 8);
        add_filter('the_content', array($this, 'render_markdown_to_html'), 9);
    }

    // ===== Settings Page =====
    public function register_settings_page() {
        add_options_page(
            __('DW Markdown', 'dwmarkdown'),
            __('DW Markdown', 'dwmarkdown'),
            'manage_options',
            'dwmarkdown-settings',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting('dwmarkdown_settings', 'dwmarkdown_editor_full_width', array('type' => 'boolean', 'sanitize_callback' => 'absint', 'default' => 0));
        register_setting('dwmarkdown_settings', 'dwmarkdown_editor_width', array('type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 800));
        register_setting('dwmarkdown_settings', 'dwmarkdown_min_characters', array('type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 1900));
        register_setting('dwmarkdown_settings', 'dwmarkdown_max_characters', array('type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 3500));
        // New: sentence highlighting settings
        register_setting('dwmarkdown_settings', 'dwmarkdown_editor_highlight_current_sentence', array('type' => 'boolean', 'sanitize_callback' => 'absint', 'default' => 1));
        register_setting('dwmarkdown_settings', 'dwmarkdown_editor_max_sentence_length', array('type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 25));
        // New: editor font size (px)
        register_setting('dwmarkdown_settings', 'dwmarkdown_editor_font_size', array('type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 16));
        // New: editor line height (unitless number)
        register_setting('dwmarkdown_settings', 'dwmarkdown_editor_line_height', array('type' => 'number', 'sanitize_callback' => 'floatval', 'default' => 1.6));

        add_settings_section('dwmarkdown_main', __('Editor Settings', 'dwmarkdown'), function(){
            echo '<p>' . esc_html__('Configure DW Markdown editor.', 'dwmarkdown') . '</p>';
        }, 'dwmarkdown-settings');

        add_settings_field('dwmarkdown_editor_full_width', __('Full width editor', 'dwmarkdown'), function(){
            $val = get_option('dwmarkdown_editor_full_width', 0);
            echo '<div class="dwmd-setting"><label><input type="checkbox" name="dwmarkdown_editor_full_width" value="1" ' . checked($val, 1, false) . ' /> ' . esc_html__('Stretch editor to full width', 'dwmarkdown') . '</label></div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

        // New: Font size
        add_settings_field('dwmarkdown_editor_font_size', __('Editor font size (px)', 'dwmarkdown'), function(){
            $val = intval(get_option('dwmarkdown_editor_font_size', 16));
            if ($val <= 0) { $val = 16; }
            echo '<div class="dwmd-setting">'
                . '<input class="small-text" style="width:110px" type="number" name="dwmarkdown_editor_font_size" min="12" max="36" step="1" value="' . esc_attr($val) . '" />'
                . '<span class="description"> ' . esc_html__('Base font size for editor and preview (default: 16).', 'dwmarkdown') . '</span>'
                . '</div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

        // New: Line height
        add_settings_field('dwmarkdown_editor_line_height', __('Editor line height', 'dwmarkdown'), function(){
            $val = get_option('dwmarkdown_editor_line_height', 1.6);
            $val = floatval($val);
            if ($val <= 0) { $val = 1.6; }
            echo '<div class="dwmd-setting">'
                . '<input class="small-text" style="width:110px" type="number" name="dwmarkdown_editor_line_height" min="1.2" max="2.4" step="0.05" value="' . esc_attr($val) . '" />'
                . '<span class="description"> ' . esc_html__('Unitless multiplier applied to editor and preview (default: 1.6).', 'dwmarkdown') . '</span>'
                . '</div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

        add_settings_field('dwmarkdown_editor_width', __('Editor width (px)', 'dwmarkdown'), function(){
            $val = intval(get_option('dwmarkdown_editor_width', 800));
            echo '<div class="dwmd-setting" id="dwmd-width-field">'
                . '<input id="dwmd_width_input" class="small-text" style="width:110px" type="number" name="dwmarkdown_editor_width" min="400" max="2000" step="10" value="' . esc_attr($val) . '" />'
                . '<span id="dwmd_width_note" class="description" style="display:none;"> ' . esc_html__('Ignored when "Full width editor" is enabled.', 'dwmarkdown') . '</span>'
                . '</div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

        add_settings_field('dwmarkdown_min_characters', __('Minimum Characters', 'dwmarkdown'), function(){
            $val = intval(get_option('dwmarkdown_min_characters', get_option('content_generator_min_characters', 1900)));
            echo '<div class="dwmd-setting">'
                . '<input class="regular-text" style="width:80px" type="number" name="dwmarkdown_min_characters" min="0" max="200000" step="50" value="' . esc_attr($val) . '" />'
                . '<span class="dwmd-status-badge dwmd-status-below" id="min-status">Below ' . $val . '</span>'
                . '<div class="description">' . esc_html__('Minimum number of characters for content (default: 1900). Character count below this will be highlighted in red.', 'dwmarkdown') . '</div>'
                . '</div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

        add_settings_field('dwmarkdown_max_characters', __('Maximum Characters', 'dwmarkdown'), function(){
            $val = intval(get_option('dwmarkdown_max_characters', get_option('content_generator_max_characters', 3500)));
            echo '<div class="dwmd-setting">'
                . '<input class="regular-text" style="width:80px" type="number" name="dwmarkdown_max_characters" min="0" max="200000" step="50" value="' . esc_attr($val) . '" />'
                . '<span class="dwmd-status-badge dwmd-status-above" id="max-status">Above ' . $val . '</span>'
                . '<div class="description">' . esc_html__('Maximum number of characters for content (default: 3500). Character count above this will be highlighted in red.', 'dwmarkdown') . '</div>'
                . '</div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

        add_settings_field('dwmarkdown_character_range', '', function(){
            $min = intval(get_option('dwmarkdown_min_characters', get_option('content_generator_min_characters', 1900)));
            $max = intval(get_option('dwmarkdown_max_characters', get_option('content_generator_max_characters', 3500)));
            echo '<div class="dwmd-setting">'
                . '<span class="dwmd-status-badge dwmd-status-good" id="range-status">Between ' . $min . ' and ' . $max . '</span>'
                . '<div class="description">' . esc_html__('Character count within range will be highlighted in green', 'dwmarkdown') . '</div>'
                . '</div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

        // Legend/preview for sentence highlighting colors
        add_settings_field('dwmarkdown_sentence_legend', __('Highlight preview', 'dwmarkdown'), function(){
            echo '<div class="dwmd-setting dwmd-legend">'
                . '<span class="dwmd-chip dwmd-chip-current" title="Current sentence"></span>' . esc_html__('Current sentence', 'dwmarkdown') . ' &nbsp; '
                . '<span class="dwmd-chip dwmd-chip-dim" title="Dimmed text"></span>' . esc_html__('Dimmed text', 'dwmarkdown') . ' &nbsp; '
                . '<span class="dwmd-chip dwmd-chip-long" title="Too long sentence"></span>' . esc_html__('Too long sentence', 'dwmarkdown')
                . '</div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

        // New: Highlight current sentence toggle
        add_settings_field('dwmarkdown_editor_highlight_current_sentence', __('Highlight current sentence', 'dwmarkdown'), function(){
            $val = get_option('dwmarkdown_editor_highlight_current_sentence', 1);
            echo '<div class="dwmd-setting"><label class="dwmd-toggle"><input type="checkbox" name="dwmarkdown_editor_highlight_current_sentence" value="1" ' . checked($val, 1, false) . ' /> <span>' . esc_html__('Focus current sentence and dim others', 'dwmarkdown') . '</span></label></div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

        // New: Max words per sentence
        add_settings_field('dwmarkdown_editor_max_sentence_length', __('Max words per sentence', 'dwmarkdown'), function(){
            $val = intval(get_option('dwmarkdown_editor_max_sentence_length', 25));
            echo '<div class="dwmd-setting"><input class="small-text" style="width:110px" type="number" name="dwmarkdown_editor_max_sentence_length" min="1" max="2000" step="1" value="' . esc_attr($val) . '" />'
                . '<span class="description"> ' . esc_html__('Sentences longer than this get a subtle red background.', 'dwmarkdown') . '</span>'
                . '</div>';
        }, 'dwmarkdown-settings', 'dwmarkdown_main');

    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <style>
                .dwmd-setting { display:flex; align-items:center; gap:8px; margin-bottom:8px; }
                .dwmd-setting .description { margin-left:0; margin-top:4px; font-style:italic; color:#666; }
                .dwmd-legend { gap:14px; margin:6px 0; }
                .dwmd-chip { display:inline-block; width:18px; height:18px; border-radius:4px; margin-right:6px; vertical-align:middle; border:1px solid rgba(0,0,0,0.15); }
                .dwmd-chip-current { background: #1e90ff22; border-color:#1e90ff55; }
                .dwmd-chip-dim { background: #666; opacity:0.5; }
                .dwmd-chip-long { background: rgba(164,22,22,0.28); border-color: rgba(164,22,22,0.5); }
                .dwmd-status-badge { 
                    display:inline-block; 
                    padding:4px 8px; 
                    border-radius:4px; 
                    font-size:12px; 
                    font-weight:500; 
                    margin-left:8px;
                }
                .dwmd-status-below, .dwmd-status-above { 
                    background:#dc3545; 
                    color:white; 
                }
                .dwmd-status-good { 
                    background:#28a745; 
                    color:white; 
                }
                .dwmd-toggle input[type="checkbox"] { margin-right:8px; }
                .dwmd-disabled { opacity: 0.5; }
            </style>
            <form action="options.php" method="post">
                <?php settings_fields('dwmarkdown_settings'); ?>
                <?php do_settings_sections('dwmarkdown-settings'); ?>
                <?php submit_button(); ?>
            </form>
            <script>
                (function(){
                    function qs(sel){ return document.querySelector(sel); }
                    function updateWidthDisabled(){
                        var cb = qs('input[name="dwmarkdown_editor_full_width"]');
                        var input = qs('#dwmd_width_input');
                        var container = qs('#dwmd-width-field');
                        var note = qs('#dwmd_width_note');
                        if(!cb || !input || !container) return;
                        var full = cb.checked;
                        // Keep value submitted to server; use readOnly instead of disabled
                        input.readOnly = !!full;
                        if (container) container.classList.toggle('dwmd-disabled', !!full);
                        if (note) note.style.display = full ? 'inline' : 'none';
                    }
                    document.addEventListener('DOMContentLoaded', updateWidthDisabled);
                    document.addEventListener('change', function(e){
                        if (e.target && e.target.name === 'dwmarkdown_editor_full_width') updateWidthDisabled();
                    });
                    // Run once on load in case DOMContentLoaded fired before inline script
                    updateWidthDisabled();
                })();
            </script>
        </div>
        <?php
    }

    public function enqueue_markdown_editor_assets($hook) {
        if (!in_array($hook, array('post.php', 'post-new.php'))) {
            return;
        }
        
        // Determine current post ID in editor context
        $post_id = 0;
        if (get_the_ID()) {
            $post_id = (int) get_the_ID();
        } elseif (!empty($_GET['post'])) {
            $post_id = (int) $_GET['post'];
        }
        
        // If DW Markdown is disabled for this post, don't enqueue any assets
        if ($post_id && get_post_meta($post_id, '_dwmarkdown_disabled', true)) {
            return;
        }

        // Paths
        $base_url  = plugin_dir_url(__FILE__);
        $base_path = plugin_dir_path(__FILE__);

        // SimpleMDE (local-first, fallback to CDN). CodeMirror is bundled inside SimpleMDE.
        $smde_css_rel = 'assets/vendor/simplemde/simplemde.min.css';
        $smde_js_rel  = 'assets/vendor/simplemde/simplemde.min.js';
        $smde_css_abs = $base_path . $smde_css_rel;
        $smde_js_abs  = $base_path . $smde_js_rel;
        $smde_ver     = '1.11.2';

        if (file_exists($smde_css_abs)) {
            wp_enqueue_style('dwmd-simplemde', $base_url . $smde_css_rel, array(), filemtime($smde_css_abs));
        } else {
            wp_enqueue_style('dwmd-simplemde', 'https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.css', array(), $smde_ver);
        }

        if (file_exists($smde_js_abs)) {
            wp_enqueue_script('dwmd-simplemde', $base_url . $smde_js_rel, array(), filemtime($smde_js_abs), true);
        } else {
            wp_enqueue_script('dwmd-simplemde', 'https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.js', array(), $smde_ver, true);
        }

        // Font Awesome 4 for SimpleMDE toolbar icons (local-first, fallback to CDN)
        $fa_css_rel = 'assets/vendor/fontawesome-4.7.0/css/font-awesome.min.css';
        $fa_css_abs = $base_path . $fa_css_rel;
        $fa_ver     = '4.7.0';
        if (file_exists($fa_css_abs)) {
            wp_enqueue_style('dwmd-fa', $base_url . $fa_css_rel, array(), filemtime($fa_css_abs));
        } else {
            wp_enqueue_style('dwmd-fa', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), $fa_ver);
        }

        // Our CSS (use filemtime for cache-busting; depend on vendor CSS for order)
        $dwmd_css_rel = 'assets/css/markdown-editor.css';
        $dwmd_css_abs = $base_path . $dwmd_css_rel;
        $dwmd_css_ver = file_exists($dwmd_css_abs) ? filemtime($dwmd_css_abs) : DWMARKDOWN_VERSION;
        wp_enqueue_style(
            'dwmarkdown-editor-css',
            $base_url . $dwmd_css_rel,
            array('dwmd-simplemde', 'dwmd-fa'),
            $dwmd_css_ver
        );

        // Our JS (also use plugin version for cache-busting)
        // Turndown (HTML -> Markdown) and GFM plugin
        // Load from CDN; if you prefer local copies later, swap URLs similar to SimpleMDE above
        wp_enqueue_script(
            'dwmd-turndown',
            'https://unpkg.com/turndown/dist/turndown.js',
            array(),
            '7.2.0',
            true
        );
        wp_enqueue_script(
            'dwmd-turndown-gfm',
            'https://unpkg.com/turndown-plugin-gfm/dist/turndown-plugin-gfm.js',
            array('dwmd-turndown'),
            DWMARKDOWN_VERSION,
            true
        );

        wp_enqueue_script(
            'dwmarkdown-editor-js',
            $base_url . 'assets/js/markdown-editor.js',
            array('jquery', 'dwmd-simplemde', 'dwmd-turndown', 'dwmd-turndown-gfm'),
            DWMARKDOWN_VERSION,
            true
        );

        // Guard against duplicate/conflicting handles enqueued by other plugins on editor screens
        $dup_style_handles  = array('simplemde', 'font-awesome', 'fontawesome', 'font-awesome-5');
        $dup_script_handles = array('simplemde', 'codemirror');
        foreach ($dup_style_handles as $h) {
            if (wp_style_is($h, 'enqueued')) {
                wp_dequeue_style($h);
            }
        }
        foreach ($dup_script_handles as $h) {
            if (wp_script_is($h, 'enqueued')) {
                wp_dequeue_script($h);
            }
        }

        // Resolve settings (DWMarkdown options only)
        $opt_full_width = (int) get_option('dwmarkdown_editor_full_width');
        $opt_width = (int) get_option('dwmarkdown_editor_width');
        // Clamp to avoid 0/empty causing collapse
        if ($opt_width <= 0) { $opt_width = 800; }
        $opt_min_chars = (int) get_option('dwmarkdown_min_characters');
        $opt_max_chars = (int) get_option('dwmarkdown_max_characters');
        $opt_highlight_sentence = (int) get_option('dwmarkdown_editor_highlight_current_sentence');
        $opt_max_sentence_len = (int) get_option('dwmarkdown_editor_max_sentence_length');
        $opt_font_size = (int) get_option('dwmarkdown_editor_font_size');
        $opt_line_height = (float) get_option('dwmarkdown_editor_line_height');
        if ($opt_font_size <= 0) { $opt_font_size = 16; }
        if ($opt_line_height <= 0) { $opt_line_height = 1.6; }

        // Apply editor base font size (editor and preview)
        if ($opt_font_size > 0) {
            $fs = max(12, min(36, (int) $opt_font_size));
            // Target both descendant and combined class wrapper cases
            $fs_css = '.dwmd-editor .CodeMirror, .dwmd-editor.CodeMirror{font-size:' . $fs . 'px !important;}' .
                      '.dwmd-editor .CodeMirror pre{font-size:' . $fs . 'px !important;}' .
                      '.dwmd-editor .editor-preview, .dwmd-editor .editor-preview-side{font-size:' . $fs . 'px !important;}';
            wp_add_inline_style('dwmarkdown-editor-css', $fs_css);
        }

        // Apply line height (editor and preview)
        if ($opt_line_height > 0) {
            $lh = max(1.2, min(2.4, (float) $opt_line_height));
            $lh_css = '.dwmd-editor .CodeMirror, .dwmd-editor.CodeMirror{line-height:' . $lh . ' !important;}' .
                      '.dwmd-editor .CodeMirror pre{line-height:' . $lh . ' !important;}' .
                      '.dwmd-editor .editor-preview, .dwmd-editor .editor-preview-side{line-height:' . $lh . ';}';
            wp_add_inline_style('dwmarkdown-editor-css', $lh_css);
        }

        // Apply editor width from DWMarkdown settings when not full-width
        if (!$opt_full_width && $opt_width > 0) {
            $w = max(400, min(2000, (int) $opt_width));
            // Constrain the scroller rather than inner lines to avoid overflow-induced scrollbars
            $inline_css =
                '.dwmd-editor .CodeMirror-scroll{max-width:' . $w . 'px;margin:0 auto !important;padding:0 !important;overflow-x:hidden !important;}' .
                '.editor-preview, .editor-preview-side{max-width:' . $w . 'px;margin:0 auto;padding:0;}';
            wp_add_inline_style('dwmarkdown-editor-css', $inline_css);
        }

        // Localized vars expected by the script
        wp_localize_script(
            'dwmarkdown-editor-js',
            'markdown_editor_vars',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'autosave_nonce' => $post_id ? wp_create_nonce('dwmarkdown_autosave_' . $post_id) : '',
                'convert_to_markdown_nonce' => wp_create_nonce('convert_to_markdown_nonce'),
                'convert_to_html_nonce' => wp_create_nonce('convert_to_html_nonce'),
                'post_id' => $post_id,
                // Keep existing option names for now to avoid a settings migration
                'min_characters' => (int) $opt_min_chars,
                'max_characters' => (int) $opt_max_chars,
                'editor_full_width' => (int) $opt_full_width,
                'editor_width' => (int) $opt_width,
                'editor_highlight_current_sentence' => (int) $opt_highlight_sentence,
                'editor_max_sentence_length' => (int) $opt_max_sentence_len,
                'languagetool_debug_mode' => '0'
            )
        );
    }

    public function replace_editor($return, $post) {
        // If DW Markdown is disabled for this post, don't modify the editor
        if ($post && get_post_meta($post->ID, '_dwmarkdown_disabled', true)) {
            return $return;
        }
        
        // Force classic editor and prepare content pipeline
        add_filter('use_block_editor_for_post', '__return_false');
        add_filter('the_editor_content', array($this, 'prepare_editor_content'), 10, 2);
        return $return;
    }

    public function prepare_editor_content($content, $post_id) {
        // If DW Markdown is disabled for this post, return content as-is
        if ($post_id && get_post_meta($post_id, '_dwmarkdown_disabled', true)) {
            return $content;
        }
        
        $is_markdown = get_post_meta($post_id, '_contains_markdown', true);
        if ($is_markdown) {
            return html_entity_decode($content, ENT_QUOTES, 'UTF-8');
        }
        if (!class_exists('Content_Generator_Markdown_Utils')) {
            require_once plugin_dir_path(__FILE__) . 'includes/class-markdown-utils.php';
        }
        return Content_Generator_Markdown_Utils::html_to_markdown($content);
    }

    public function mark_post_as_markdown($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;
        if (!current_user_can('edit_post', $post_id)) return;
        
        // If DW Markdown is disabled for this post, don't mark as markdown
        if (get_post_meta($post_id, '_dwmarkdown_disabled', true)) {
            delete_post_meta($post_id, '_contains_markdown');
            return;
        }
        
        // Mark all post types as containing markdown when saved
        update_post_meta($post_id, '_contains_markdown', 'true');
    }

    public function render_markdown_to_html($content) {
        if (is_singular() && !is_admin()) {
            global $post;
            if ($post && !get_post_meta($post->ID, '_dwmarkdown_disabled', true) && get_post_meta($post->ID, '_contains_markdown', true)) {
                if (!class_exists('Content_Generator_Markdown_Utils')) {
                    require_once plugin_dir_path(__FILE__) . 'includes/class-markdown-utils.php';
                }
                // If cards are enabled for this post, render as Bootstrap Article Cards
                $cards_enabled = get_post_meta($post->ID, '_dwmarkdown_cards_enabled', true);
                if ($cards_enabled) {
                    $cols_desktop = (int) get_post_meta($post->ID, '_dwmarkdown_cards_cols_desktop', true);
                    $cols_tablet  = (int) get_post_meta($post->ID, '_dwmarkdown_cards_cols_tablet', true);
                    $cols_mobile  = (int) get_post_meta($post->ID, '_dwmarkdown_cards_cols_mobile', true);
                    if ($cols_desktop <= 0) { $cols_desktop = 4; }
                    if ($cols_tablet  <= 0) { $cols_tablet  = 3; }
                    if ($cols_mobile  <= 0) { $cols_mobile  = 1; }

                    return $this->render_markdown_as_bootstrap_cards($content, $cols_desktop, $cols_tablet, $cols_mobile);
                }

                $rendered = Content_Generator_Markdown_Utils::markdown_to_html($content);
                $content = html_entity_decode($rendered, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            }
        }
        return $content;
    }

    public function maybe_disable_wpautop($content) {
        if (is_singular() && !is_admin()) {
            global $post;
            if ($post && !get_post_meta($post->ID, '_dwmarkdown_disabled', true) && get_post_meta($post->ID, '_contains_markdown', true)) {
                remove_filter('the_content', 'wpautop');
            }
        }
        return $content;
    }

    /**
     * Secure AJAX autosave handler used by the editor as a fallback
     */
    public function handle_autosave() {
        $post_id = isset($_POST['post_ID']) ? intval($_POST['post_ID']) : 0;
        if (!$post_id) {
            wp_send_json_error(array('message' => 'Missing post ID'), 400);
        }
        
        // If DW Markdown is disabled for this post, don't handle autosave
        if (get_post_meta($post_id, '_dwmarkdown_disabled', true)) {
            wp_send_json_error(array('message' => 'DW Markdown disabled for this post'), 400);
        }
        
        // Verify nonce bound to this post
        $nonce = isset($_POST['_dwmarkdown_nonce']) ? sanitize_text_field($_POST['_dwmarkdown_nonce']) : '';
        if (!$nonce || !wp_verify_nonce($nonce, 'dwmarkdown_autosave_' . $post_id)) {
            wp_send_json_error(array('message' => 'Invalid nonce'), 403);
        }
        if (!current_user_can('edit_post', $post_id)) {
            wp_send_json_error(array('message' => 'Insufficient permissions'), 403);
        }
        $content = isset($_POST['content']) ? wp_unslash($_POST['content']) : '';
        // Update content without changing post status
        $update = wp_update_post(array(
            'ID' => $post_id,
            'post_content' => $content,
        ), true);
        if (is_wp_error($update)) {
            wp_send_json_error(array('message' => $update->get_error_message()), 500);
        }
        update_post_meta($post_id, '_contains_markdown', 'true');
        wp_send_json_success(array('updated' => $update));
    }

    /**
     * Add meta box to disable DW Markdown per post
     */
    public function add_disable_metabox() {
        $post_types = get_post_types(array('public' => true), 'names');
        foreach ($post_types as $post_type) {
            add_meta_box(
                'dwmarkdown_disable',
                __('DW Markdown', 'dwmarkdown'),
                array($this, 'render_disable_metabox'),
                $post_type,
                'side',
                'default'
            );
        }
    }

    /**
     * Render the disable meta box
     */
    public function render_disable_metabox($post) {
        wp_nonce_field('dwmarkdown_disable_nonce', 'dwmarkdown_disable_nonce');
        $disabled = get_post_meta($post->ID, '_dwmarkdown_disabled', true);
        ?>
        <p>
            <label>
                <input type="checkbox" name="dwmarkdown_disabled" value="1" <?php checked($disabled, '1'); ?> />
                <?php _e('Use standard classic editor (disable DW Markdown)', 'dwmarkdown'); ?>
            </label>
        </p>
        <p class="description">
            <?php _e('When checked, this post will use the standard WordPress classic editor instead of the Markdown editor. No HTML↔Markdown conversions will occur.', 'dwmarkdown'); ?>
        </p>
        <?php
    }

    /**
     * Save the disable meta box
     */
    public function save_disable_metabox($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;
        if (!isset($_POST['dwmarkdown_disable_nonce']) || !wp_verify_nonce($_POST['dwmarkdown_disable_nonce'], 'dwmarkdown_disable_nonce')) return;
        if (!current_user_can('edit_post', $post_id)) return;

        if (isset($_POST['dwmarkdown_disabled']) && $_POST['dwmarkdown_disabled'] == '1') {
            update_post_meta($post_id, '_dwmarkdown_disabled', '1');
        } else {
            delete_post_meta($post_id, '_dwmarkdown_disabled');
        }
    }

    /**
     * Add meta box to configure Bootstrap Article Cards per post
     */
    public function add_cards_metabox() {
        $post_types = get_post_types(array('public' => true), 'names');
        foreach ($post_types as $post_type) {
            add_meta_box(
                'dwmarkdown_cards',
                __('DW Markdown – Cards', 'dwmarkdown'),
                array($this, 'render_cards_metabox'),
                $post_type,
                'side',
                'default'
            );
        }
    }

    /**
     * Render the cards meta box
     */
    public function render_cards_metabox($post) {
        wp_nonce_field('dwmarkdown_cards_nonce', 'dwmarkdown_cards_nonce');
        $enabled = get_post_meta($post->ID, '_dwmarkdown_cards_enabled', true);
        $cols_desktop = (int) get_post_meta($post->ID, '_dwmarkdown_cards_cols_desktop', true);
        $cols_tablet  = (int) get_post_meta($post->ID, '_dwmarkdown_cards_cols_tablet', true);
        $cols_mobile  = (int) get_post_meta($post->ID, '_dwmarkdown_cards_cols_mobile', true);
        if ($cols_desktop <= 0) { $cols_desktop = 4; }
        if ($cols_tablet  <= 0) { $cols_tablet  = 3; }
        if ($cols_mobile  <= 0) { $cols_mobile  = 1; }
        ?>
        <p>
            <label>
                <input type="checkbox" name="dwmarkdown_cards_enabled" value="1" <?php checked($enabled, '1'); ?> />
                <?php _e('Render as Bootstrap Article Cards (split by H2)', 'dwmarkdown'); ?>
            </label>
        </p>
        <div class="dwmd-cards-grid">
            <p>
                <label for="dwmarkdown_cards_cols_desktop"><strong><?php _e('Desktop columns', 'dwmarkdown'); ?></strong></label>
                <input type="number" class="small-text" id="dwmarkdown_cards_cols_desktop" name="dwmarkdown_cards_cols_desktop" min="1" max="6" step="1" value="<?php echo esc_attr($cols_desktop); ?>" />
            </p>
            <p>
                <label for="dwmarkdown_cards_cols_tablet"><strong><?php _e('Tablet columns', 'dwmarkdown'); ?></strong></label>
                <input type="number" class="small-text" id="dwmarkdown_cards_cols_tablet" name="dwmarkdown_cards_cols_tablet" min="1" max="6" step="1" value="<?php echo esc_attr($cols_tablet); ?>" />
            </p>
            <p>
                <label for="dwmarkdown_cards_cols_mobile"><strong><?php _e('Mobile columns', 'dwmarkdown'); ?></strong></label>
                <input type="number" class="small-text" id="dwmarkdown_cards_cols_mobile" name="dwmarkdown_cards_cols_mobile" min="1" max="6" step="1" value="<?php echo esc_attr($cols_mobile); ?>" />
            </p>
            <p class="description"><?php _e('Defaults: Desktop 4, Tablet 3, Mobile 1. Columns map to Bootstrap grid widths.', 'dwmarkdown'); ?></p>
        </div>
        <?php
    }

    /**
     * Save the cards meta box
     */
    public function save_cards_metabox($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;
        if (!isset($_POST['dwmarkdown_cards_nonce']) || !wp_verify_nonce($_POST['dwmarkdown_cards_nonce'], 'dwmarkdown_cards_nonce')) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $enabled = isset($_POST['dwmarkdown_cards_enabled']) && $_POST['dwmarkdown_cards_enabled'] == '1' ? '1' : '';
        if ($enabled) {
            update_post_meta($post_id, '_dwmarkdown_cards_enabled', '1');
        } else {
            delete_post_meta($post_id, '_dwmarkdown_cards_enabled');
        }

        $cols_desktop = isset($_POST['dwmarkdown_cards_cols_desktop']) ? intval($_POST['dwmarkdown_cards_cols_desktop']) : 4;
        $cols_tablet  = isset($_POST['dwmarkdown_cards_cols_tablet']) ? intval($_POST['dwmarkdown_cards_cols_tablet']) : 3;
        $cols_mobile  = isset($_POST['dwmarkdown_cards_cols_mobile']) ? intval($_POST['dwmarkdown_cards_cols_mobile']) : 1;

        $cols_desktop = max(1, min(6, $cols_desktop));
        $cols_tablet  = max(1, min(6, $cols_tablet));
        $cols_mobile  = max(1, min(6, $cols_mobile));

        update_post_meta($post_id, '_dwmarkdown_cards_cols_desktop', $cols_desktop);
        update_post_meta($post_id, '_dwmarkdown_cards_cols_tablet', $cols_tablet);
        update_post_meta($post_id, '_dwmarkdown_cards_cols_mobile', $cols_mobile);
    }

    /**
     * Render Markdown as a grid of Bootstrap cards, splitting sections by H2 (##) headings.
     * Each H2 becomes the card title; the section content becomes the card body.
     *
     * @param string $markdown       Full post markdown
     * @param int    $cols_desktop   Columns on desktop (>= lg)
     * @param int    $cols_tablet    Columns on tablet (>= md)
     * @param int    $cols_mobile    Columns on mobile (< md)
     * @return string                HTML of cards
     */
    protected function render_markdown_as_bootstrap_cards($markdown, $cols_desktop, $cols_tablet, $cols_mobile) {
        // 1) Identify first H2 position
        $first_h2_pos = null;
        if (preg_match('/^\s*##\s+/m', $markdown, $m, PREG_OFFSET_CAPTURE)) {
            $first_h2_pos = $m[0][1];
        }
        if ($first_h2_pos === null) {
            // No H2 sections; fallback to standard rendering
            $html = Content_Generator_Markdown_Utils::markdown_to_html($markdown);
            return html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        // 2) Identify last horizontal rule (---) position
        $last_hr_pos = null;
        if (preg_match_all('/^\s*---\s*$/m', $markdown, $hr_matches, PREG_OFFSET_CAPTURE)) {
            $last = end($hr_matches[0]);
            if ($last) {
                $last_hr_pos = $last[1];
            }
        }

        // 3) Split into pre, main (cards), post
        $pre_md  = substr($markdown, 0, $first_h2_pos);
        if ($last_hr_pos !== null && $last_hr_pos > $first_h2_pos) {
            $main_md = substr($markdown, $first_h2_pos, $last_hr_pos - $first_h2_pos);
            // Advance past the hr line to get post
            // Find line length of that hr match
            if (preg_match('/^.*$/m', substr($markdown, $last_hr_pos), $line_m)) {
                $post_start = $last_hr_pos + strlen($line_m[0]);
            } else {
                $post_start = $last_hr_pos;
            }
            $post_md = substr($markdown, $post_start);
        } else {
            // No HR after first H2: everything after first H2 is cards, no post tail
            $main_md = substr($markdown, $first_h2_pos);
            $post_md = '';
        }

        // 4) Build cards from main_md by splitting on H2
        $parts = preg_split('/^\s*##\s+(.*?)\s*$/m', $main_md, -1, PREG_SPLIT_DELIM_CAPTURE);
        if (!$parts || count($parts) < 3) {
            // Somehow main section has no proper H2; fallback to standard rendering
            $html = Content_Generator_Markdown_Utils::markdown_to_html($markdown);
            return html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        $cards = array();
        for ($i = 1; $i < count($parts); $i += 2) {
            $title = trim($parts[$i]);
            $section_md = isset($parts[$i + 1]) ? trim($parts[$i + 1]) : '';
            $body_html = Content_Generator_Markdown_Utils::markdown_to_html($section_md);
            $body_html = html_entity_decode($body_html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($title !== '' || $body_html !== '') {
                $cards[] = array(
                    'title' => $title,
                    'body'  => $body_html,
                );
            }
        }

        // Compute Bootstrap column classes
        $cols_desktop = max(1, min(12, (int) $cols_desktop));
        $cols_tablet  = max(1, min(12, (int) $cols_tablet));
        $cols_mobile  = max(1, min(12, (int) $cols_mobile));

        $w_mobile  = max(1, min(12, (int) floor(12 / $cols_mobile)));
        $w_tablet  = max(1, min(12, (int) floor(12 / $cols_tablet)));
        $w_desktop = max(1, min(12, (int) floor(12 / $cols_desktop)));

        $col_classes = sprintf('col-12 col-sm-%d col-md-%d col-lg-%d', $w_mobile, $w_tablet, $w_desktop);

        // 5) Render pre and post normally
        $pre_html = '';
        if (trim($pre_md) !== '') {
            $pre_html = Content_Generator_Markdown_Utils::markdown_to_html($pre_md);
            $pre_html = html_entity_decode($pre_html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        $post_html = '';
        if (trim($post_md) !== '') {
            $post_html = Content_Generator_Markdown_Utils::markdown_to_html($post_md);
            $post_html = html_entity_decode($post_html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        // 6) Build HTML
        $out = '';
        if ($pre_html !== '') {
            $out .= '<div class="dwmd-cards-preamble">' . $pre_html . '</div>';
        }
        if (!empty($cards)) {
            $out .= '<div class="dwmd-cards container-fluid">';
            $out .= '<div class="row g-3">';
            foreach ($cards as $card) {
                $out .= '<div class="' . esc_attr($col_classes) . '">';
                $out .= '  <article class="card h-100 dwmd-article-card">';
                $out .= '    <div class="card-body">';
                $out .= '      <h3 class="card-title">' . esc_html($card['title']) . '</h3>';
                $out .= '      <div class="card-text">' . $card['body'] . '</div>';
                $out .= '    </div>';
                $out .= '  </article>';
                $out .= '</div>';
            }
            $out .= '</div>';
            $out .= '</div>';
        }
        if ($post_html !== '') {
            $out .= '<div class="dwmd-cards-postamble">' . $post_html . '</div>';
        }

        return $out;
    }

    /**
     * Enqueue Thickbox on Plugins screen for the deactivation modal.
     */
    public function enqueue_plugins_screen_assets($hook) {
        if ($hook === 'plugins.php') {
            add_thickbox();
        }
    }

    /**
     * Modal warning when attempting to deactivate DW Markdown (mirrors EssayToolkit UX).
     */
    public function plugins_deactivation_modal() {
        ?>
        <style>
            #dwmarkdown-deactivation-warning .warning-buttons {
                margin-top: 25px;
                display: flex;
                justify-content: flex-end;
                gap: 10px;
            }
            #dwmarkdown-confirm-deactivation {
                background-color: #d63638;
                border-color: #d63638;
                color: white;
            }
            #TB_window { width: 600px !important; height: 300px !important; margin-top: 10% !important; padding: 25px !important; font-size: 16px !important; }
            #TB_window .button { margin-right: 15px !important; }
            #TB_ajaxContent { width: auto !important; height: auto !important; padding: 0 !important; }
        </style>
        <script type="text/javascript">
        jQuery(document).ready(function($){
            var warningHtml = '<div id="dwmarkdown-deactivation-warning" style="display:none;">'
                + '<h2><?php echo esc_js(__('Warning: Markdown Rendering Will Stop', 'dwmarkdown')); ?></h2>'
                + '<p><strong style="color:#d63638;"><?php echo esc_js(__('Important:', 'dwmarkdown')); ?></strong> <?php echo esc_js(__('Deactivating DW Markdown will disable markdown conversion to HTML.', 'dwmarkdown')); ?></p>'
                + '<p><?php echo esc_js(__('Any content using markdown format may display as raw markdown after deactivation.', 'dwmarkdown')); ?></p>'
                + '<p><?php echo esc_js(__('Consider converting markdown content to HTML before deactivating.', 'dwmarkdown')); ?></p>'
                + '<div class="warning-buttons">'
                + '<a href="#" class="button button-secondary" id="dwmarkdown-cancel-deactivation"><?php echo esc_js(__('Cancel', 'dwmarkdown')); ?></a>'
                + '<a href="#" class="button button-primary" id="dwmarkdown-confirm-deactivation"><?php echo esc_js(__('Continue with deactivation', 'dwmarkdown')); ?></a>'
                + '</div>'
                + '</div>';
            $('body').append(warningHtml);

            var deactivationUrl = '';
            var selector = 'tr[data-slug="dwmarkdown"] .deactivate a, a[href*="action=deactivate"][href*="dwmarkdown"]';
            $(document).on('mouseenter', selector, function(){ deactivationUrl = $(this).attr('href'); });
            $(document).on('click', selector, function(e){
                e.preventDefault();
                deactivationUrl = $(this).attr('href');
                tb_show('', '#TB_inline?width=600&height=300&inlineId=dwmarkdown-deactivation-warning');
                $('#TB_title').remove();
                return false;
            });
            $(document).on('click', '#dwmarkdown-cancel-deactivation', function(e){ e.preventDefault(); tb_remove(); return false; });
            $(document).on('click', '#dwmarkdown-confirm-deactivation', function(e){ e.preventDefault(); if (deactivationUrl) { window.location.href = deactivationUrl; } return false; });
        });
        </script>
        <?php
    }

    /**
     * Outputs a small CSS override to ensure the classic editor uses light text/background
     * when DW Markdown is disabled for the current post. This counters dark editor styles
     * from core/editor.min.css or theme-provided editor styles.
     */
    public function output_classic_editor_lightmode_css() {
        // Determine current post ID only on post.php; on post-new.php there is no existing post
        $post_id = 0;
        if (isset($_GET['post'])) {
            $post_id = (int) $_GET['post'];
        } elseif (get_the_ID()) {
            $post_id = (int) get_the_ID();
        }

        if (!$post_id) {
            // No post context; nothing to do
            return;
        }

        // Only apply when DW Markdown is explicitly disabled for this post
        if (!get_post_meta($post_id, '_dwmarkdown_disabled', true)) {
            return;
        }

        // Output scoped CSS for classic editor textarea and TinyMCE iframe body
        echo '<style id="dwmd-classic-editor-lightmode">'
            // Scope under our body class if present; also include unscoped as fallback
            . 'body.dwmd-disabled-editor .wp-editor-wrap .wp-editor-area,'
            . 'body.dwmd-disabled-editor .wp-editor-area,'
            . 'body.dwmd-disabled-editor .quicktags-toolbar + .wp-editor-area,'
            . '.wp-editor-wrap .wp-editor-area{color:#1e1e1e !important;background:#ffffff !important;caret-color:#1e1e1e !important;}'
            // Post title field
            . 'body.dwmd-disabled-editor #titlewrap #title,'
            . '#titlewrap #title{color:#1e1e1e !important;background:#ffffff !important;caret-color:#1e1e1e !important;}'
            // Generic text inputs and textareas in editor screen
            . 'body.dwmd-disabled-editor input[type="text"],'
            . 'body.dwmd-disabled-editor textarea{color:#1e1e1e !important;background:#ffffff !important;}'
            . 'body.dwmd-disabled-editor .mce-content-body,'
            . '.mce-content-body{color:#1e1e1e !important;background:#ffffff !important;}'
            // Neutralize possible is-dark-theme influences
            . 'body.dwmd-disabled-editor.is-dark-theme .wp-editor-area{color:#1e1e1e !important;background:#ffffff !important;}'
            . '</style>';
    }

    /**
     * Adds a body class on post editor screens when DW Markdown is disabled for the post.
     */
    public function maybe_add_disabled_body_class($classes) {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || ($screen->base !== 'post' && $screen->base !== 'post-new')) {
            return $classes;
        }
        $post_id = 0;
        if (isset($_GET['post'])) {
            $post_id = (int) $_GET['post'];
        } elseif (get_the_ID()) {
            $post_id = (int) get_the_ID();
        }
        if ($post_id && get_post_meta($post_id, '_dwmarkdown_disabled', true)) {
            // Add our flag class
            $classes .= ' dwmd-disabled-editor';
            // Also remove is-dark-theme token if present to avoid core dark overrides
            $classes = preg_replace('/\bis-dark-theme\b/', '', $classes);
        }
        return $classes;
    }

    /**
     * Ensures TinyMCE iframe (Visual tab) uses light text/background when DW Markdown is disabled.
     * Uses the 'content_style' TinyMCE init setting to inject CSS inside the iframe document.
     *
     * @param array  $init       TinyMCE settings
     * @param string $editor_id  Editor ID (usually 'content')
     * @return array
     */
    public function tweak_classic_editor_tinymce_styles($init) {
        // Only on post edit screens
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || ($screen->base !== 'post' && $screen->base !== 'post-new')) {
            return $init;
        }

        // Resolve post ID
        $post_id = 0;
        if (isset($_GET['post'])) {
            $post_id = (int) $_GET['post'];
        } elseif (get_the_ID()) {
            $post_id = (int) get_the_ID();
        }

        if (!$post_id) {
            return $init;
        }

        // Only apply when DW Markdown is explicitly disabled
        if (!get_post_meta($post_id, '_dwmarkdown_disabled', true)) {
            return $init;
        }

        $css = 'html, body, body#tinymce, body.mce-content-body{background:#ffffff !important;color:#1e1e1e !important;}'
             . 'body.mce-content-body, body#tinymce{background:#ffffff !important;color:#1e1e1e !important;}'
             . 'p, div, span, li, blockquote, pre, code{color:#1e1e1e !important;}'
             . ':root{color-scheme: light !important;}';

        if (!empty($init['content_style'])) {
            $init['content_style'] .= ' ' . $css;
        } else {
            $init['content_style'] = $css;
        }

        return $init;
    }

    /**
     * Strips theme/editor CSS from TinyMCE iframe when DW Markdown is disabled for the post,
     * to prevent dark editor styles from overriding our light content styling.
     */
    public function maybe_strip_theme_mce_css($mce_css) {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || ($screen->base !== 'post' && $screen->base !== 'post-new')) {
            return $mce_css;
        }
        $post_id = 0;
        if (isset($_GET['post'])) {
            $post_id = (int) $_GET['post'];
        } elseif (get_the_ID()) {
            $post_id = (int) get_the_ID();
        }
        if (!$post_id || !get_post_meta($post_id, '_dwmarkdown_disabled', true)) {
            return $mce_css;
        }

        // When disabled, remove all theme/editor styles from TinyMCE to avoid dark text.
        // $mce_css is a comma-separated list of URLs. We can either return empty or filter.
        // Return empty to be safest.
        return '';
    }
}

function dwmarkdown_init_plugin() {
    // Ensure utils are autoloadable when needed
    // no-op now, main class will require when needed
    new DWMarkdown();
}
add_action('plugins_loaded', 'dwmarkdown_init_plugin');
